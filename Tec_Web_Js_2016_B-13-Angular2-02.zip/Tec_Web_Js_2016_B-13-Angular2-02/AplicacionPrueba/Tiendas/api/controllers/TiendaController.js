/**
 * TiendaController
 *
 * @description :: Server-side logic for managing Tiendas
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

