# Introducción a TypeScript y EcmaScript

## Editor en línea
Para trabajar con los ejemplos dirigirse al siguiente enlace:

[JSPlayground](https://stephengrider.github.io/JSPlaygrounds/)

## Instalación de Angular 2

Para instalar Angular 2 debemos dirigirnos a la documentación oficial del cliente:

[Angular CLi](https://github.com/angular/angular-cli)


